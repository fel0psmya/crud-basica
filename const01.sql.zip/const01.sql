-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 30-Dez-2020 às 23:05
-- Versão do servidor: 10.4.17-MariaDB
-- versão do PHP: 8.0.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `const01`
--
CREATE DATABASE IF NOT EXISTS `const01` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `const01`;

-- --------------------------------------------------------

--
-- Estrutura da tabela `cargo`
--

CREATE TABLE `cargo` (
  `id` int(11) NOT NULL,
  `titulo` varchar(40) NOT NULL,
  `salario_inicial` int(11) NOT NULL,
  `id_dep` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `cargo`
--

INSERT INTO `cargo` (`id`, `titulo`, `salario_inicial`, `id_dep`) VALUES
(1, 'Gerente', 3000, 1),
(2, 'Modelador', 2000, 2),
(3, 'Administrador', 1800, 3);

-- --------------------------------------------------------

--
-- Estrutura da tabela `departamento`
--

CREATE TABLE `departamento` (
  `id` int(11) NOT NULL,
  `nome` varchar(40) NOT NULL,
  `sigla` varchar(10) NOT NULL,
  `id_dep_principal` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `departamento`
--

INSERT INTO `departamento` (`id`, `nome`, `sigla`, `id_dep_principal`) VALUES
(1, 'Gerência', 'G', 1),
(2, 'Modelagem de Projetos', 'MP', 1),
(3, 'Recursos Humanos', 'RH', 1);

-- --------------------------------------------------------

--
-- Estrutura da tabela `dependente`
--

CREATE TABLE `dependente` (
  `id` int(11) NOT NULL,
  `d_nome` varchar(30) NOT NULL,
  `data_de_nascimento` date NOT NULL,
  `id_func` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `dependente`
--

INSERT INTO `dependente` (`id`, `d_nome`, `data_de_nascimento`, `id_func`) VALUES
(1, 'Felipe ', '2003-06-04', 2),
(2, 'Soares', '2003-03-09', 3),
(3, 'Marcelo', '2002-01-04', 1);

-- --------------------------------------------------------

--
-- Estrutura da tabela `desenvolve`
--

CREATE TABLE `desenvolve` (
  `id` int(11) NOT NULL,
  `id_func` int(11) NOT NULL,
  `id_proj` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `desenvolve`
--

INSERT INTO `desenvolve` (`id`, `id_func`, `id_proj`) VALUES
(1, 2, 1),
(2, 2, 2);

-- --------------------------------------------------------

--
-- Estrutura da tabela `funcionario`
--

CREATE TABLE `funcionario` (
  `id` int(11) NOT NULL,
  `nome` varchar(30) NOT NULL,
  `rg` varchar(11) NOT NULL,
  `data_de_nascimento` date NOT NULL,
  `contato` varchar(11) NOT NULL,
  `id_func_supervisor` int(11) NOT NULL,
  `id_cargo` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `funcionario`
--

INSERT INTO `funcionario` (`id`, `nome`, `rg`, `data_de_nascimento`, `contato`, `id_func_supervisor`, `id_cargo`) VALUES
(1, 'Osmar', '010101', '1900-06-09', '101010', 1, 1),
(2, 'Carlos', '020202', '1990-08-09', '202020', 1, 2),
(3, 'Dias', '030303', '1991-08-09', '303030', 1, 3);

-- --------------------------------------------------------

--
-- Estrutura da tabela `projeto`
--

CREATE TABLE `projeto` (
  `id` int(11) NOT NULL,
  `apelido` varchar(30) NOT NULL,
  `descricao` text NOT NULL,
  `id_dep` int(11) NOT NULL,
  `id_func_lider` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `projeto`
--

INSERT INTO `projeto` (`id`, `apelido`, `descricao`, `id_dep`, `id_func_lider`) VALUES
(1, 'EEEP CÉSAR CALS', 'AGORA VAI', 2, 2),
(2, 'Sede Fundação Nipônica', 'Fundação Nipônica em Fortaleza', 2, 2);

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `cargo`
--
ALTER TABLE `cargo`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `nome` (`titulo`),
  ADD KEY `id_dep` (`id_dep`);

--
-- Índices para tabela `departamento`
--
ALTER TABLE `departamento`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `sigla` (`sigla`);

--
-- Índices para tabela `dependente`
--
ALTER TABLE `dependente`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_func` (`id_func`);

--
-- Índices para tabela `desenvolve`
--
ALTER TABLE `desenvolve`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_func` (`id_func`),
  ADD KEY `id_proj` (`id_proj`);

--
-- Índices para tabela `funcionario`
--
ALTER TABLE `funcionario`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `rg` (`rg`),
  ADD KEY `id_cargo` (`id_cargo`);

--
-- Índices para tabela `projeto`
--
ALTER TABLE `projeto`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `apelido` (`apelido`),
  ADD KEY `id_dep` (`id_dep`),
  ADD KEY `id_func_lider` (`id_func_lider`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `cargo`
--
ALTER TABLE `cargo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de tabela `departamento`
--
ALTER TABLE `departamento`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de tabela `dependente`
--
ALTER TABLE `dependente`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de tabela `desenvolve`
--
ALTER TABLE `desenvolve`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de tabela `funcionario`
--
ALTER TABLE `funcionario`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de tabela `projeto`
--
ALTER TABLE `projeto`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Restrições para despejos de tabelas
--

--
-- Limitadores para a tabela `cargo`
--
ALTER TABLE `cargo`
  ADD CONSTRAINT `cargo_ibfk_1` FOREIGN KEY (`id_dep`) REFERENCES `departamento` (`id`);

--
-- Limitadores para a tabela `dependente`
--
ALTER TABLE `dependente`
  ADD CONSTRAINT `dependente_ibfk_1` FOREIGN KEY (`id_func`) REFERENCES `funcionario` (`id`);

--
-- Limitadores para a tabela `desenvolve`
--
ALTER TABLE `desenvolve`
  ADD CONSTRAINT `desenvolve_ibfk_1` FOREIGN KEY (`id_func`) REFERENCES `funcionario` (`id`),
  ADD CONSTRAINT `desenvolve_ibfk_2` FOREIGN KEY (`id_proj`) REFERENCES `projeto` (`id`);

--
-- Limitadores para a tabela `funcionario`
--
ALTER TABLE `funcionario`
  ADD CONSTRAINT `funcionario_ibfk_1` FOREIGN KEY (`id_cargo`) REFERENCES `cargo` (`id`);

--
-- Limitadores para a tabela `projeto`
--
ALTER TABLE `projeto`
  ADD CONSTRAINT `projeto_ibfk_1` FOREIGN KEY (`id_dep`) REFERENCES `departamento` (`id`),
  ADD CONSTRAINT `projeto_ibfk_2` FOREIGN KEY (`id_func_lider`) REFERENCES `funcionario` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
